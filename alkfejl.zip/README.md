# MotorControllerTelemetry

Development of Software Applications homework. (Also a (really)  useful application to monitor electric drive systems.)
